<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="[A]WaterFall_pipo" tilewidth="32" tileheight="32" tilecount="576" columns="32">
 <image source="[A]WaterFall_pipo.png" width="1024" height="576"/>
</tileset>
