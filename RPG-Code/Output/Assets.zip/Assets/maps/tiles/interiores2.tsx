<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="interiores2" tilewidth="32" tileheight="32" tilecount="288" columns="12">
 <image source="interiores2.png" width="384" height="768"/>
</tileset>
