<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="sombras_ext" tilewidth="32" tileheight="32" tilecount="192" columns="16" backgroundcolor="#00ff00">
 <image source="sombras_ext.png" width="512" height="384"/>
</tileset>
