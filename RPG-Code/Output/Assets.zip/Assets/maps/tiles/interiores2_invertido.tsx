<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="interiores2_invertido" tilewidth="32" tileheight="32" tilecount="288" columns="12">
 <image source="interiores2_invertido.png" width="384" height="768"/>
</tileset>
