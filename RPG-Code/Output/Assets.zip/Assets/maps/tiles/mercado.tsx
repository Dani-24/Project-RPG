<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="mercado" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="mercado.png" width="256" height="256"/>
</tileset>
