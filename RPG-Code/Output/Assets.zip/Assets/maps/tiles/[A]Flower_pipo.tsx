<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="[A]Flower_pipo" tilewidth="32" tileheight="32" tilecount="96" columns="8">
 <image source="[A]Flower_pipo.png" width="256" height="384"/>
 <wangsets>
  <wangset name="Flower" type="corner" tile="36">
   <wangcolor name="Flower" color="#ff0000" tile="37" probability="1"/>
   <wangcolor name="HighGrass" color="#00ff00" tile="61" probability="1"/>
   <wangtile tileid="5" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="6" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="7" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="13" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="14" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="15" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="21" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="22" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="23" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="28" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="29" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="36" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="37" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="53" wangid="0,0,0,2,0,0,0,0"/>
   <wangtile tileid="54" wangid="0,0,0,2,0,2,0,0"/>
   <wangtile tileid="55" wangid="0,0,0,0,0,2,0,0"/>
   <wangtile tileid="61" wangid="0,2,0,2,0,0,0,0"/>
   <wangtile tileid="62" wangid="0,2,0,2,0,2,0,2"/>
   <wangtile tileid="63" wangid="0,0,0,0,0,2,0,2"/>
   <wangtile tileid="69" wangid="0,2,0,0,0,0,0,0"/>
   <wangtile tileid="70" wangid="0,2,0,0,0,0,0,2"/>
   <wangtile tileid="71" wangid="0,0,0,0,0,0,0,2"/>
   <wangtile tileid="76" wangid="0,2,0,0,0,2,0,2"/>
   <wangtile tileid="77" wangid="0,2,0,2,0,0,0,2"/>
   <wangtile tileid="84" wangid="0,0,0,2,0,2,0,2"/>
   <wangtile tileid="85" wangid="0,2,0,2,0,2,0,0"/>
  </wangset>
 </wangsets>
</tileset>
