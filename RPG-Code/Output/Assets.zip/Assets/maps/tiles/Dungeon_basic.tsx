<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.0" name="Dungeon_basic" tilewidth="32" tileheight="32" tilecount="2560" columns="64">
 <image source="dungeon_1/mainlevbuild.png" width="2048" height="1280"/>
</tileset>
