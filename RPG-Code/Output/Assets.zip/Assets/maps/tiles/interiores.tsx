<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="interiores" tilewidth="32" tileheight="32" tilecount="240" columns="16">
 <image source="interiores.png" width="512" height="480"/>
</tileset>
